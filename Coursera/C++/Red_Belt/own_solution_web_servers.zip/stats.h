#pragma once

#include "http_request.h"

#include <string_view>
#include <map>
#include <iostream>
#include <set>
#include <vector>
using namespace std;

class Stats {
public:
  void AddMethod(string_view method)
  {
    if (method_stats.count(method) == 0) method_stats["UNKNOWN"]++;
    else method_stats[method]++;
  }
  void AddUri(string_view uri)
  {
    if (uri_stats.count(uri) == 0) uri_stats["unknown"]++;
    else  uri_stats[uri]++;
  }
  const map<string_view, int>& GetMethodStats() const
  {return method_stats;}
  const map<string_view, int>& GetUriStats() const
  {return uri_stats;}
private:
  map<string_view, int> method_stats = {{"GET", 0}, {"POST", 0}, {"PUT", 0},
                                              {"DELETE", 0}, {"UNKNOWN", 0}};
  map<string_view, int> uri_stats = {{"/", 0}, {"/order", 0}, {"/product", 0},
                                    {"/basket", 0}, {"/help", 0}, {"unknown", 0}};
};

HttpRequest ParseRequest(string_view str);
