#include "test_runner.h"
#include "http_request.h"
#include "stats.h"

HttpRequest ParseRequest(string_view str)
{
  HttpRequest http;

  while (str.front() == ' ') {str.remove_prefix(1);}

  size_t space = str.find(' ');
  http.method = str.substr(0, space);

  str.remove_prefix(space + 1);

  space = str.find(' ');
  http.uri = str.substr(0, space);

  str.remove_prefix(space + 1);

  space = str.find(' ');
  http.protocol = str.substr(0, space);

  return http;
}
